---
name: Packaging requests
about: For packages that are missing
title: 'Package request: PACKAGENAME'
labels: '0.kind: packaging request'
assignees: ''

---

**Project description**

<!-- Describe the project a little: -->

**Metadata**

* homepage URL:
* source URL:
* license: mit, bsd, gpl2+ , ...
* platforms: unix, linux, darwin, ...
