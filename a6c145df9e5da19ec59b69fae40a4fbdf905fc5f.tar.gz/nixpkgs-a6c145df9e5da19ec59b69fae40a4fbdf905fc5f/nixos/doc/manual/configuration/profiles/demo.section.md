# Demo {#sec-profile-demo}

This profile just enables a `demo` user, with password `demo`, uid `1000`, `wheel` group and
[autologin in the SDDM display manager](#opt-services.xserver.displayManager.autoLogin).
