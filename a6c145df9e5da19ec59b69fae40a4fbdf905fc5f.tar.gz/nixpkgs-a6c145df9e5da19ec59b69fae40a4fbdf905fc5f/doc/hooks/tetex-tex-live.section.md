
### teTeX / TeX Live {#tetex-tex-live}

Adds the `share/texmf-nix` subdirectory of each build input to the `TEXINPUTS` environment variable.
